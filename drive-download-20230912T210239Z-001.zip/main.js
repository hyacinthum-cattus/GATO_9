// Crea una variable lienzo


block_y=1;
block_x=1;

block_image_width = 350;
block_image_height = 480;

var bloque_objeto_imagen= "";

// Completa la función nueva_imagen() para agregar una nueva imagen
function nueva_imagen(get_image)
{
	






	

}

window.addEventListener("keydown", mi_TeclaPulsada);

function mi_TeclaPulsada(e)
{
teclaPresionada = e.keyCode;
console.log(teclaPresionada);
	// Usa el código de tecla apropiado para agregar la imagen roja
	if(teclaPresionada == ) 
	{



	}
	// Usa el código de tecla apropiado para agregar la imagen verde
	if(teclaPresionada == )
	{
	


	}
	// Usa el código de tecla apropiado para agregar la imagen amarilla
	if(teclaPresionada == )
	{

		

	}
	// Usa el código de tecla apropiado para agregar la imagen rosa
	if(teclaPresionada == )
	{
	


	}
	// Usa el código de tecla apropiado para agregar la imagen azul
	if(teclaPresionada == )
	{



	}
	
}

